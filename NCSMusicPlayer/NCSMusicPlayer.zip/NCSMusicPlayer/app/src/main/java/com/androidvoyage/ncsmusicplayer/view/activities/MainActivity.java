package com.androidvoyage.ncsmusicplayer.view.activities;

import android.arch.lifecycle.ViewModelProvider;
import android.net.Uri;
import android.support.annotation.NonNull;
import android.support.design.widget.BottomNavigationView;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.MenuItem;
import android.widget.FrameLayout;

import com.androidvoyage.ncsmusicplayer.R;
import com.androidvoyage.ncsmusicplayer.view.fragments.SongsList;

import butterknife.BindView;
import butterknife.ButterKnife;

public class MainActivity extends AppCompatActivity implements SongsList.OnFragmentInteractionListener, BottomNavigationView.OnNavigationItemSelectedListener {


    @BindView(R.id.bottomNavigation)
    private BottomNavigationView bottomNavigationView;

    @BindView(R.id.mainContentLayout)
    private FrameLayout frameLayout;


    public static String TAG = "MainActivity";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        ButterKnife.bind(this);
        bottomNavigationView.setOnNavigationItemSelectedListener(this);

    }

    @Override
    public void onFragmentInteraction(Uri uri) {

    }

    @Override
    public boolean onNavigationItemSelected(@NonNull MenuItem menuItem) {
        switch (menuItem.getItemId()) {
            case R.id.action_ncs:
                break;
            case R.id.action_music:
                break;
            case R.id.action_settings:
                break;
        }
        return true;
    }
}
