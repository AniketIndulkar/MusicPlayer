package com.androidvoyage.ncsmusicplayer.utils;

public class Utils {
}
